function problemOne(biscuits, workersCount, competitorBiscuits) {
  let biscuitsPerMonth = 0;

  for (let i = 1; i <= 30; i++) {
    let biscuitsPerDay = biscuits * workersCount;
    if (i % 3 !== 0) {
      biscuitsPerMonth += biscuitsPerDay;
    } else {
      biscuitsPerDay = Math.floor(biscuitsPerDay * 0.75);
      biscuitsPerMonth += biscuitsPerDay;
    }
  }

  console.log(
    `You have produced ${biscuitsPerMonth} biscuits for the past month.`
  );

  let differenceMore = 0;
  let differenceLess = 0;

  if (biscuitsPerMonth > competitorBiscuits) {
    differenceMore = biscuitsPerMonth - competitorBiscuits;
  } else {
    differenceLess = competitorBiscuits - biscuitsPerMonth;
  }

  let percentageDifferenceMore = (differenceMore / competitorBiscuits) * 100;
  let percentageDifferenceLess = (differenceLess / competitorBiscuits) * 100;

  if (percentageDifferenceLess < percentageDifferenceMore) {
    console.log(
      `You produce ${percentageDifferenceMore.toFixed(
        2
      )} percent more biscuits.`
    );
  } else {
    console.log(
      `You produce ${percentageDifferenceLess.toFixed(
        2
      )} percent less biscuits.`
    );
  }
}

problemOne(1, 1, 1);
